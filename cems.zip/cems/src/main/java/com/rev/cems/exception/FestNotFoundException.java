package com.rev.cems.exception;

public class FestNotFoundException extends RuntimeException {

	public FestNotFoundException(String msg){
		super(msg);
	}
}
