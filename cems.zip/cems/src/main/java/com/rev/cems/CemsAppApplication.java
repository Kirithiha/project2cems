package com.rev.cems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CemsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CemsAppApplication.class, args);
	}

}
