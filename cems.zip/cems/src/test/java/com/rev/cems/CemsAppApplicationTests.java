package com.rev.cems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CemsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
